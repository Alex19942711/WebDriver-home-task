﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using SeleniumGoogle.Handlers;

namespace SeleniumGoogle;

public  class OnlyTests:HomePageObject
{
    public IWebDriver _webDriver;
    


    [OneTimeSetUp]

    public void DoBeforeAllTheTests()
    {
        _webDriver = new FirefoxDriver();
    }


    [TearDown]
    public void DoAfterEachTests()
    {
        _webDriver.Quit();
    }

    [SetUp]
    public void DobeforeEach()
    {
        _webDriver.Manage().Cookies.DeleteAllCookies();
        _webDriver.Navigate().GoToUrl(TestSettings.HostPrefix);
        _webDriver.Manage().Window.Maximize();
    }

    

    [Test]
     public void Test()
     {
        Thread.Sleep(TimeSpan.FromSeconds(3));
        var homePage = new CheckImageSteps(_webDriver);

        Assert.IsTrue(homePage.CheckPresentPicture());
     }
       
    
}
