﻿using System;

namespace SeleniumGoogle
{
	public class TestSettings
	{
		public static string HostPrefix = "https://www.google.com";
	}
}

