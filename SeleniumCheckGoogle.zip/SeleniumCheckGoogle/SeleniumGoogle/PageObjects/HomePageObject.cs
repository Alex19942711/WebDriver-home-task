﻿using System;
using System.Linq;
using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System.Text;
using NUnit.Framework;
using System.Threading;
using System.Threading.Tasks;
using OpenQA.Selenium.Support.UI;
using System.Collections;

namespace SeleniumGoogle
{

    public  class HomePageObject
    {
        
        public readonly By _picture = By.XPath("//img[contains(@src,'googlelogo_light_color_272x92dp.png')]");
        public readonly string picture = "googlelogo_light_color_272x92dp.png";

    }
}

