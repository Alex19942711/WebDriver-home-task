﻿using System;
using System.Linq;
using OpenQA.Selenium;

namespace SeleniumGoogle.Handlers
{
    public class CheckImageSteps:HomePageObject
    {
        public IWebDriver _webDriver;
        

        public CheckImageSteps(IWebDriver _webDriver)
        {
            this._webDriver = _webDriver;
        }


        public bool CheckPresentPicture()
        {

            try
            {
                _webDriver.PageSource.Contains(picture);
                return true;

            }

            catch (NoSuchElementException)
            {
                return false;
            }

            
        }

        public virtual void WaitFor(int time)
        {
            Thread.Sleep(TimeSpan.FromSeconds(time));
        }
    }

}